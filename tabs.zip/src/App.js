import './App.css';
import Tab from "./components/tab"

function App() {
  return (
    <div className="App">
      <Tab></Tab>
    </div>
  );
}

export default App;
